from django.contrib import admin
from imoveis.models import *
# Register your models here.
admin.site.register(Cidade)
admin.site.register(Transacao)
admin.site.register(Tipo)
admin.site.register(Quarto)
admin.site.register(Banheiro)
admin.site.register(Vaga)
admin.site.register(Anuncio)
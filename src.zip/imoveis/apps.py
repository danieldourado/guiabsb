from django.apps import AppConfig


class ImoveisConfig(AppConfig):
    name = 'imoveis'
